import java.io.*;
import java.net.Socket;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

class ThreadServidorAdivina implements Runnable {
    private Socket clientSocket;

    public ThreadServidorAdivina(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try (
                ObjectOutputStream outStream = new ObjectOutputStream(clientSocket.getOutputStream());
                ObjectInputStream inStream = new ObjectInputStream(clientSocket.getInputStream())
        ) {

            Llista lista = (Llista) inStream.readObject();
            System.out.println("Rebuda llista del client: " + lista.getNom() + " " + lista.getNumberList());

            List<Integer> numbers = lista.getNumberList();
            Collections.sort(numbers);

            LinkedHashSet<Integer> numNR = new LinkedHashSet<>(numbers);
            numbers = new ArrayList<>(numNR);

            lista.setNumberList(numbers);

            outStream.writeObject(lista);
            outStream.flush();
            System.out.println("Enviada llista ordenada i sense duplicats al client: " + lista.getNom() + " " + lista.getNumberList());
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(ThreadServidorAdivina.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}