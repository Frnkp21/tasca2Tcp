import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ClientAdivinaTcp {
    String hostname;
    int port;

    public ClientAdivinaTcp(String hostname, int port) {
        this.hostname = hostname;
        this.port = port;
    }

    public void run() {
        Socket socket;
        ObjectOutputStream out;
        ObjectInputStream in;

        try {
            socket = new Socket(InetAddress.getByName(hostname), port);
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());

            Llista llista = crearLista();
            out.writeObject(llista);
            out.flush();
            System.out.println("Llista enviada: " + llista.getNom() + " " + llista.getNumberList());

            Llista llistaModificada = (Llista) in.readObject();
            System.out.println("Llista arreglada: " + llistaModificada.getNom() + " " + llistaModificada.getNumberList());

        } catch (UnknownHostException ex) {
            System.out.println("Error de connexió. No existeix l'amfitrió: " + ex.getMessage());
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error de connexió: " + ex.getMessage());
        }
    }


    private Llista crearLista() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introdueix el nom de la llista: ");
        String nom = scanner.nextLine();
        System.out.print("Quants números vols introduir? (Introdueix un número): ");
        int numNumeros = scanner.nextInt();
        System.out.println("Introdueix els números: ");
        List<Integer> numeros = new ArrayList<>();
        int numero;

        while (numeros.size() < numNumeros) {
            numero = scanner.nextInt();
            numeros.add(numero);
        }

        return new Llista(nom, numeros);
    }

    public static void main(String[] args) {
        ClientAdivinaTcp clientTcp = new ClientAdivinaTcp("localhost", 5558);
        clientTcp.run();
    }
}
